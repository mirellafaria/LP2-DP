﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[] A = new double[10];
            double[] B = new double[10];

            for (int i = 0; i < 10; i++)
            {
                bool entradaValida = false;
                double valor = 0;

                while (!entradaValida)
                {
                    string entrada = Interaction.InputBox($"Digite o {i + 1}º número do vetor A:", "Entrada de Dados");

                    if (double.TryParse(entrada, out valor))
                    {
                        entradaValida = true;
                        A[i] = valor;
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido! Digite um número válido.", "Erro");
                    }
                }
            }

            for (int i = 0; i < 10; i++)
            {
                if (i % 2 == 0)
                    B[i] = A[i] * 10;
                else
                    B[i] = A[i] + 10;
            }

            lstResultado.Items.Clear();
            lstResultado.Items.Add("Vetor A\t\tVetor B");
            lstResultado.Items.Add("--------------------------------");

            for (int i = 0; i < 10; i++)
            {
                lstResultado.Items.Add($"A[{i}] = {A[i],5} \t B[{i}] = {B[i],5}");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstResultado.Items.Clear();
        }
    }
}
