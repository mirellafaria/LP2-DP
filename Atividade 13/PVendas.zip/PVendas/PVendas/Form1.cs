﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] produtos = { "Hambúrguer", "Cheeseburger", "Fritas", "Refrigerante", "Milkshake" };
            double[] valorUnitario = { 20.00, 25.50, 15.50, 8.00, 15.00 };

            const int DIAS = 7;
            const int ITENS = 5;

            int[,] quantidades = new int[DIAS, ITENS];

            for (int i = 0; i < DIAS; i++)
            {
                for (int j = 0; j < ITENS; j++)
                {
                    bool entradaValida = false;
                    int qtd = 0;
                    while (!entradaValida)
                    {
                        string entrada = Interaction.InputBox(
                            $"Dia {i + 1} - {produtos[j]}\nDigite a quantidade vendida:",
                            "Entrada de Vendas");

                        if (int.TryParse(entrada, out qtd) && qtd >= 0)
                        {
                            quantidades[i, j] = qtd;
                            entradaValida = true;
                        }
                        else
                        {
                            MessageBox.Show("Digite uma quantidade válida (número inteiro ≥ 0)!", "Erro");
                        }
                    }
                }
            }

            lstResultado.Items.Clear();

            for (int i = 0; i < DIAS; i++)
            {
                lstResultado.Items.Add($"===== Dia {i + 1} =====");

                for (int j = 0; j < ITENS; j++)
                {
                    double total = quantidades[i, j] * valorUnitario[j];
                    lstResultado.Items.Add(
                        $"{produtos[j],-15} | Unitário: {valorUnitario[j].ToString("C2")} | " +
                        $"Qtd: {quantidades[i, j]} | Total: {total.ToString("C2")}");
                }

                lstResultado.Items.Add("");
            }
            MessageBox.Show("Vendas registradas e exibidas com sucesso!", "Concluído");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstResultado.Items.Clear();
        }
    }
}
