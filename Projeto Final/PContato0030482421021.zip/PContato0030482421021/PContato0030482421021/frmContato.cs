﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482421021
{
    public partial class frmContato : Form
    {
        private BindingSource bnContato = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsContato = new DataSet();
        private DataSet dsCidade = new DataSet();
        public frmContato()
        {
            InitializeComponent();
        }

        private void txtEnderecoContato_TextChanged(object sender, EventArgs e)
        {

        }

        private void bindingNavigator1_RefreshItems(object sender, EventArgs e)
        {

        }

        private void frmContato_Load(object sender, EventArgs e)
        {
            try

            {
                Cidade cidade = new Cidade();
                cbxCidade.DataSource = cidade.Listar();
                cbxCidade.DisplayMember = "NOME_CIDADE";
                cbxCidade.ValueMember = "ID_CIDADE";

                Contato RegContato = new Contato();
                dsContato.Tables.Add(RegContato.Listar());
                bnContato.DataSource = dsContato.Tables["Contato"];
                dgvContato.DataSource = bnContato;
                bnvContato.BindingSource = bnContato;

                txtId.DataBindings.Add("TEXT", bnContato, "id_contato");
                txtNome.DataBindings.Add("TEXT", bnContato, "nome_contato");
                txtEndereco.DataBindings.Add("TEXT", bnContato, "end_contato");
                txtCelular.DataBindings.Add("TEXT", bnContato, "cel_contato");
                txtEmail.DataBindings.Add("TEXT", bnContato, "email_contato");
                dtpDtCadastro.DataBindings.Add("TEXT", bnContato, "dtcadastro_contato");

                cbxCidade.DataBindings.Add("SelectedItem", bnContato, "cidade_id_cidade");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnContato.CancelEdit();

            txtNome.Enabled = false;
            txtEndereco.Enabled = false;
            cbxCidade.Enabled = false;
            dtpDtCadastro.Enabled = false;
            txtCelular.Enabled = false;
            txtEmail.Enabled = false;

            btnNovo.Enabled = true;
            btnAlterar.Enabled = true;
            btnExcluir.Enabled = true;
            btnSalvar.Enabled = false;
            btnCancelar.Enabled = false;
            bInclusao = false;
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }


            bnContato.AddNew();

            txtNome.Enabled = true;
            txtNome.Focus();
            txtEndereco.Enabled = true;
            cbxCidade.Enabled = true;
            dtpDtCadastro.Enabled = true;
            txtCelular.Enabled = true;
            txtEmail.Enabled = true;

            cbxCidade.SelectedIndex = 0;

            btnNovo.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "" || (txtNome.Text.Replace(" ", "").Length < 1))
            {
                MessageBox.Show("Nome inválido!");
            }
            else if (cbxCidade.SelectedIndex == -1)
            {
                MessageBox.Show("Cidade inválida!");
            }
            else if (txtEndereco.Text == "" || txtEndereco.Text.Replace(" ", "").Length < 8)

            {
                MessageBox.Show("Endereço inválido!");
            }
            else if (Convert.ToDateTime(dtpDtCadastro.Value) < DateTime.Today)
            {
                MessageBox.Show("Data inválida!");
            }
            else if (txtCelular.Text == "" || !long.TryParse(txtCelular.Text, out long numero))
            {
                MessageBox.Show("Celular inválido!");
            }
            else if (txtEmail.Text == "" || txtEmail.Text.Replace(" ", "").Length < 8)
            {
                MessageBox.Show("Email inválido!");
            }
            else
            {
                Contato RegCont = new Contato();
                RegCont.NOME_CONTATO = txtNome.Text;
                RegCont.CIDADE_ID_CIDADE = Convert.ToInt32(cbxCidade.SelectedValue);
                RegCont.DTCADASTRO_CONTATO = dtpDtCadastro.Value;
                RegCont.END_CONTATO = txtEndereco.Text;
                RegCont.CEL_CONTATO = txtCelular.Text;
                RegCont.EMAIL_CONTATO = txtEmail.Text;

                if (bInclusao)
                {
                    if (RegCont.Incluir() > 0)
                    {
                        MessageBox.Show("Contato adicionado com sucesso");

                        txtNome.Enabled = false;
                        txtEndereco.Enabled = false;
                        cbxCidade.Enabled = false;
                        dtpDtCadastro.Enabled = false;
                        txtCelular.Enabled = false;
                        txtEmail.Enabled = false;

                        btnNovo.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;
                        bInclusao = false;

                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCont.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Contato!");
                    }
                }
                else
                {
                    RegCont.ID_CONTATO = Convert.ToInt32(txtId.Text);

                    if (RegCont.Alterar() > 0)
                    {
                        MessageBox.Show("Contato alterado com sucesso!");

                        txtNome.Enabled = false;
                        txtEndereco.Enabled = false;
                        cbxCidade.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;
                        dtpDtCadastro.Enabled = false;
                        txtCelular.Enabled = false;
                        txtEmail.Enabled = false;


                    }
                }
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            txtNome.Enabled = true;
            txtEndereco.Enabled = true;
            cbxCidade.Enabled = true;
            dtpDtCadastro.Enabled = true;
            txtCelular.Enabled = true;
            txtEmail.Enabled = true;


            btnNovo.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Contato RegCont = new Contato();
                RegCont.ID_CONTATO = Convert.ToInt32(txtId.Text);

                if (RegCont.Excluir() > 0)
                {
                    MessageBox.Show("Contato excluido com sucesso!");

                    dsContato.Tables.Clear();
                    dsContato.Tables.Add(RegCont.Listar());
                    bnContato.DataSource = dsContato.Tables["Contato"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Contato!");
                }
            }
        }
    }
}
