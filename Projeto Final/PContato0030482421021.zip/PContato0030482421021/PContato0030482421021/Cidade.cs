﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PContato0030482421021
{
    public class Cidade
    {
        private int idcidade;
        private string nomecidade;
        private string ufcidade;

        public int IdCidade
        {
            get { return idcidade; }
            set { idcidade = value; }
        }

        public string NomeCidade
        {
            get { return nomecidade; }
            set { nomecidade = value; }
        }

        public string Ufcidade
        {
            get { return ufcidade; }
            set { ufcidade = value; }
        }

        public DataTable Listar()
        {
            SqlDataAdapter daCidade;
            DataTable dtCidade = new DataTable();

            try
            {
                daCidade = new SqlDataAdapter("SELECT * FROM CIDADE ORDER BY NOME_CIDADE", frmPrincipal.conn); daCidade.Fill(dtCidade);
                daCidade.FillSchema(dtCidade, SchemaType.Source);
            }

            catch (Exception)
            {
                throw;
            }
            return dtCidade;

        }
    }
}
