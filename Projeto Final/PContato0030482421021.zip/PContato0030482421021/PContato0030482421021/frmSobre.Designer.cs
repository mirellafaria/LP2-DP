﻿namespace PContato0030482421021
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInfo = new System.Windows.Forms.Label();
            this.lblTexto = new System.Windows.Forms.Label();
            this.lblAluno = new System.Windows.Forms.Label();
            this.lblEu = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfo.Location = new System.Drawing.Point(12, 20);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(325, 26);
            this.lblInfo.TabIndex = 0;
            this.lblInfo.Text = "Informações sobre a aplicação";
            this.lblInfo.Click += new System.EventHandler(this.lblInfo_Click);
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblTexto.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto.Location = new System.Drawing.Point(13, 58);
            this.lblTexto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(503, 46);
            this.lblTexto.TabIndex = 2;
            this.lblTexto.Text = "Aplicação com utilização de Banco de Dados em tabela \r\ncom o objetivo da realizaç" +
    "ão de cadastro de alunos.\r\n";
            this.lblTexto.Click += new System.EventHandler(this.lblTexto_Click);
            // 
            // lblAluno
            // 
            this.lblAluno.AutoSize = true;
            this.lblAluno.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAluno.Location = new System.Drawing.Point(12, 160);
            this.lblAluno.Name = "lblAluno";
            this.lblAluno.Size = new System.Drawing.Size(326, 26);
            this.lblAluno.TabIndex = 3;
            this.lblAluno.Text = "Aluno responsável pelo projeto:";
            // 
            // lblEu
            // 
            this.lblEu.AutoSize = true;
            this.lblEu.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblEu.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEu.Location = new System.Drawing.Point(13, 197);
            this.lblEu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEu.Name = "lblEu";
            this.lblEu.Size = new System.Drawing.Size(225, 46);
            this.lblEu.TabIndex = 4;
            this.lblEu.Text = "Mirella de Oliveira Faria \r\n3° sem. 2025\r\n";
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblEu);
            this.Controls.Add(this.lblAluno);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.lblInfo);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Label lblAluno;
        private System.Windows.Forms.Label lblEu;
    }
}