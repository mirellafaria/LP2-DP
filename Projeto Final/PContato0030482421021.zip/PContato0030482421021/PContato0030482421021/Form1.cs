﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;


namespace PContato0030482421021
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conn;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Database=LP2;Trusted_Connection=True");
                conn.Open();

            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados = /" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros erro = /" + ex.Message);
            }
        }

        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmContato>().Count() > 0)
            {
                Application.OpenForms["frmContato"].BringToFront();
            }
            else
            {
                frmContato FrmContato = new frmContato();
                FrmContato.MdiParent = this;
                FrmContato.WindowState = FormWindowState.Maximized;
                FrmContato.Show();

            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre FrmSobre = new frmSobre();
                FrmSobre.MdiParent = this;
                FrmSobre.WindowState = FormWindowState.Maximized;
                FrmSobre.Show();

            }
        }

       

    }
}
