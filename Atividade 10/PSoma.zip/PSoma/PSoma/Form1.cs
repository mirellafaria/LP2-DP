﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSoma
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int N;
            double soma = 0;

            if (!int.TryParse(txtN.Text, out N))
            {
                MessageBox.Show("Digite um número inteiro válido!");
                txtN.Focus();
                return;
            }

            if (N <= 0 || N >= 50)
            {
                MessageBox.Show("O valor de N deve ser maior que 0 e menor que 50.");
                txtN.Focus();
                return;
            }

            for (int i = 1; i <= N; i++)
            {
                soma += (double)i / (i + 1);
            }

            MessageBox.Show($"A soma dos {N} primeiros termos é: {soma:F4}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtN.Clear();
            txtN.Focus();
        }
    }
}
