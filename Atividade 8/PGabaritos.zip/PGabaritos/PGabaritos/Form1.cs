﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PGabaritos
{
    public partial class Form1 : Form
    {
        // Vetor fixo do gabarito
        char[] gabarito = { 'A', 'C', 'B', 'D', 'A', 'E', 'C', 'B', 'D', 'A' };

        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            // Exemplo: último dígito do RA = 7 → N = 8
            string ra = Interaction.InputBox("Digite o seu RA (somente números):", "RA do aluno");
            if (string.IsNullOrWhiteSpace(ra))
            {
                MessageBox.Show("Operação cancelada.");
                return;
            }

            int ultimoDigito = 0;
            if (!int.TryParse(ra[1].ToString(), out ultimoDigito))
            {
                MessageBox.Show("RA inválido!");
                return;
            }

            int N = (ultimoDigito == 0) ? 2 : ultimoDigito + 1;
            char[,] respostas = new char[N, 10];

            // Limpa o ListBox antes de começar
            lstResultados.Items.Clear();

            // Recebe respostas de cada aluno
            for (int i = 0; i < N; i++)
            {
                int acertos = 0;

                for (int j = 0; j < 10; j++)
                {
                    string entrada = "";
                    bool valido = false;

                    // Repetir até digitar uma letra válida (A–E)
                    while (!valido)
                    {
                        entrada = Interaction.InputBox($"Aluno {i + 1} - Questão {j + 1} (A, B, C, D ou E):", "Resposta");

                        if (string.IsNullOrWhiteSpace(entrada))
                        {
                            MessageBox.Show("Entrada cancelada. Encerrando.");
                            return;
                        }

                        entrada = entrada.Trim().ToUpper();

                        if ("ABCDE".Contains(entrada))
                        {
                            valido = true;
                            respostas[i, j] = entrada[0];
                        }
                        else
                        {
                            MessageBox.Show("Digite apenas A, B, C, D ou E!");
                        }
                    }

                    // Comparação com o gabarito
                    if (respostas[i, j] == gabarito[j])
                    {
                        acertos++;
                        lstResultados.Items.Add($"Aluno: {i + 1} acertou a questão:{j + 1} era {gabarito[j]} escolheu {respostas[i, j]} ");
                    }
                    else 
                    {
                        lstResultados.Items.Add($"Aluno: {i + 1} errou a questão:{j + 1} era {gabarito[j]} escolheu {respostas[i, j]}");
                    }
                }

            }

            MessageBox.Show($"Total de alunos corrigidos: {N}", "Correção concluída");
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
