﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PCompra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            const int LINHAS = 7;  
            const int COLUNAS = 5; 
            double[,] compras = new double[LINHAS, COLUNAS];
            double[] totalPorDia = new double[LINHAS];
            double totalGeral = 0;

            for (int i = 0; i < LINHAS; i++)
            {
                for (int j = 0; j < COLUNAS; j++)
                {
                    bool entradaValida = false;
                    double valor = 0;

                    while (!entradaValida)
                    {
                        string entrada = Interaction.InputBox(
                            $"Digite o valor do produto {j + 1} no dia {i + 1}:",
                            "Entrada de dados da compra");

                        if (double.TryParse(entrada, out valor) && valor >= 0)
                        {
                            compras[i, j] = valor;
                            entradaValida = true;
                        }
                        else
                        {
                            MessageBox.Show("Digite um valor numérico maior ou igual a 0!", "Erro");
                        }
                    }
                }
            }

            for (int i = 0; i < LINHAS; i++)
            {
                totalPorDia[i] = 0;

                for (int j = 0; j < COLUNAS; j++)
                {
                    totalPorDia[i] += compras[i, j];
                }

                totalGeral += totalPorDia[i];
            }

            lstResultado.Items.Clear();
            lstResultado.Items.Add("Total por dia:");
            lstResultado.Items.Add("-------------------------------");

            for (int i = 0; i < LINHAS; i++)
            {
                lstResultado.Items.Add($"Dia {i + 1}: {totalPorDia[i].ToString("C2")}");
            }

            lstResultado.Items.Add("-------------------------------");
            lstResultado.Items.Add($"Total Geral: {totalGeral.ToString("C2")}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstResultado.Items.Clear();
        }
    }
}
