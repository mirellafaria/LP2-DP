﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace POrdena
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            List<string> palavras = new List<string>();

            for (int i = 0; i < 20; i++)
            {
                string palavra = Interaction.InputBox($"Digite a {i + 1}ª palavra:", "Entrada de palavras");
                palavras.Add(palavra);
            }

            palavras.Sort();

            string resultado = string.Join(Environment.NewLine, palavras);
            MessageBox.Show("Palavras ordenadas:\n\n" + resultado);
        }

        private void btnArray_Click(object sender, EventArgs e)
        {
            string[] palavras = new string[20];

            for (int i = 0; i < 20; i++)
            {
                palavras[i] = Interaction.InputBox($"Digite a {i + 1}ª palavra:", "Entrada de palavras");
            }

            Array.Sort(palavras);

            string resultado = string.Join(Environment.NewLine, palavras);
            MessageBox.Show("Palavras ordenadas:\n\n" + resultado);
        }
    }
}
