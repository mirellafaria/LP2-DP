﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        float peso;
        float altura;
        float imc;

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!float.TryParse(mtxtPesoAtual.Text, out peso)
                   || peso <= 0
                   || peso >= 1000
                   )
            {
                MessageBox.Show("Peso inválido");
                mtxtPesoAtual.Focus();
            }
            else
            {
                if (!float.TryParse(mtxtAltura.Text, out altura) || altura <= 0 || altura >= 3)
                {
                    MessageBox.Show("Altura inválida");
                    mtxtAltura.Focus();
                }
                else
                {
                    imc = peso / (altura * altura);
                    if (imc < 18.5)
                    {
                        txtIMC.Text = "Magreza";
                    }
                    else
                    {
                        if (imc <= 24.9)
                        {
                            txtIMC.Text = "Normal";
                        }
                        else
                        {
                            if (imc <= 29.9)
                            {
                                txtIMC.Text = "Sobrepeso";
                            }
                            else
                            {
                                if (imc <= 39.9)
                                {
                                    txtIMC.Text = "Obesidade";
                                }
                                else
                                {
                                    txtIMC.Text = "Obesidade Grave";
                                }
                            }
                        }
                    }
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mtxtAltura.Clear();
            mtxtPesoAtual.Clear();
            txtIMC.Clear();
            altura = 0;
            peso = 0;
            imc = 0;
            mtxtPesoAtual.Focus();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mtxtPesoAtual_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
 
        }

        private void mtxtAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}

