﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMedias
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcularMedias_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[10, 3]; 
            StringBuilder resultado = new StringBuilder();

            for (int i = 0; i < 10; i++) 
            {
                for (int j = 0; j < 3; j++) 
                {
                    double nota = -1;

                    while (nota < 0 || nota > 10)
                    {
                        string entrada = Interaction.InputBox(
                            $"Aluno {i + 1} - Digite a nota {j + 1} (0 a 10):",
                            "Entrada de notas");

                        if (string.IsNullOrWhiteSpace(entrada))
                        {
                            MessageBox.Show("Entrada cancelada. Encerrando.");
                            return;
                        }

                        if (double.TryParse(entrada.Replace(",", "."), out nota))
                        {
                            if (nota < 0 || nota > 10)
                                MessageBox.Show("A nota deve estar entre 0 e 10!");
                        }
                        else
                        {
                            MessageBox.Show("Digite um número válido!");
                            nota = -1;
                        }
                    }

                    notas[i, j] = nota;
                }
            }

            for (int i = 0; i < 10; i++)
            {
                double soma = 0;
                for (int j = 0; j < 3; j++)
                    soma += notas[i, j];

                double media = soma / 3.0;
                resultado.AppendLine($"Aluno {i + 1}: média {media:F1}");
            }

            MessageBox.Show(resultado.ToString(), "Médias da Turma");
        }
    }
}
