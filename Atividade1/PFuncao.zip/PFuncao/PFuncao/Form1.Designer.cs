﻿namespace PFuncao
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtValX = new System.Windows.Forms.TextBox();
            this.lblValX = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblValy = new System.Windows.Forms.Label();
            this.txtValy = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtValX
            // 
            this.txtValX.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValX.Location = new System.Drawing.Point(208, 130);
            this.txtValX.Name = "txtValX";
            this.txtValX.Size = new System.Drawing.Size(100, 30);
            this.txtValX.TabIndex = 0;
            // 
            // lblValX
            // 
            this.lblValX.AutoSize = true;
            this.lblValX.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValX.Location = new System.Drawing.Point(21, 133);
            this.lblValX.Name = "lblValX";
            this.lblValX.Size = new System.Drawing.Size(172, 25);
            this.lblValX.TabIndex = 1;
            this.lblValX.Text = "Digite o valor de x:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(64, 259);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(178, 75);
            this.btnCalcular.TabIndex = 2;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblValy
            // 
            this.lblValy.AutoSize = true;
            this.lblValy.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValy.Location = new System.Drawing.Point(21, 184);
            this.lblValy.Name = "lblValy";
            this.lblValy.Size = new System.Drawing.Size(100, 25);
            this.lblValy.TabIndex = 3;
            this.lblValy.Text = "Valor de y";
            // 
            // txtValy
            // 
            this.txtValy.Enabled = false;
            this.txtValy.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValy.Location = new System.Drawing.Point(208, 181);
            this.txtValy.Name = "txtValy";
            this.txtValy.Size = new System.Drawing.Size(100, 30);
            this.txtValy.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtValy);
            this.Controls.Add(this.lblValy);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblValX);
            this.Controls.Add(this.txtValX);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtValX;
        private System.Windows.Forms.Label lblValX;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblValy;
        private System.Windows.Forms.TextBox txtValy;
    }
}

