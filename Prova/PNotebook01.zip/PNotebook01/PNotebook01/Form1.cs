﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PNotebook01
{
    public partial class Form1 : Form
    {
        double[,] vendas = new double[3, 3];
        
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstResultado.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] notebook = { "Notebook 1", "Notebook 2", "Notebook 3" };
            string[] loja = { "Loja 1", "Loja 2", "Loja 3" };

            const int NOTE = 3;
            const int LOJA = 3;

            int[,] quantidades = new int[NOTE, LOJA];

            for (int i = 0; i < NOTE; i++)
            {
                for (int j = 0; j < LOJA; j++)
                {

                }
            }












        }
    }
}
